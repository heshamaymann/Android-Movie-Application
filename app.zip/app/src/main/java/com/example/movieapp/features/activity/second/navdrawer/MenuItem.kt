package com.example.movieapp.features.activity.second.navdrawer

data class MenuItem(
    val name: String,
    val img: Int,
    val id: Int
)



