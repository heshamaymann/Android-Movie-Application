package com.example.movieapp.features.fragment

data class


ItemCharacter(
    val image: String,
    val id: Int,
    val name: String,
    val gender: String,
    val status: String ,
    val episode :List<String>
)
